/******************************************************************************
 * Copyright 2020 IndiaSells
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *****************************************************************************/
#ifndef CLOUD_H
#define CLOUD_H

#include "hardware.h"

/* declaration of the function */
void wifi_start(struct cloud_def *);
String check_ip();
int check_wifi(void);
String getJwt(void);
bool publish_state(String);
int mqtt_connect(bool);
void send_device_info (void);
String device_info(void);
void connect(void);
void start_mqtt(void);
int setup_iot_cloud(struct cloud_def *);
void check_mqtt_reconnect();
int log_error(void);
int log_return_code(void);

#endif