#include <web_server.h>
#include "server_response.h"
#include <ArduinoJson.h>

AsyncWebServer server(80);

String vars;

const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE HTML><html><head>
<title>SMART-STRIP Input Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script>  
function submitMessage() {
  alert("Saved value to ESP SPIFFS");
  setTimeout(function(){ document.location.reload(false); }, 500);   
}
function parseThis(element) {
  var xhr = new XMLHttpRequest();
  xhr.open("GET", "/update?WIFI_NAME="+ element.form.wifiname.value \
           + "&PASS=" + element.form.pass.value \
           + "&PROJECT_ID=" + element.form.project_id.value \
           + "&LOCATION=" + element.form.location.value \
           + "&DEVICE_ID" + element.form.device_id.value \
           + "&PRIVATE_KEY" + element.form.private_key.value \
           + "&REGISTRY_ID" + element.form.registry_id.value, true);
  xhr.send();
}
</script></head><body>
<form action="/get" target="hidden-form">
WIFI_NAME : <input type="text" name="WIFI_NAME" id="wifiname">
<br><br>
PASS : <input type="text" name="PASS" id="pass">
<br><br>
PROJECT_ID : <input type="text" name="PROJECT_ID" id="project_id">
<br><br>
LOCATION : <input type="text" name="LOCATION" id="location">
<br><br>
DEVICE_ID : <input type="text" name="DEVICE_ID" id="device_id">
<br><br>
PRIVATE-KEY : <input type="text" name="PRIVATE_KEY" id="private_key">
<br><br>
REGISTRY_ID : <input type="text" name="REGISTRY_ID" id="registry_id">
<br><br>
<input type="submit" value="Submit" onclick="parseThis(this)">
</form>
<iframe style="display:none" name="hidden-form"></iframe>
</body></html>)rawliteral";

void not_found(AsyncWebServerRequest *request) {
  request->send(404, "text/plain", "Not found");
}

/**
 * webserver - enable local_server when device in AP_mode
 * args: void
 * return: void   
*/
void local_server() {
  PRINTR("Entering in While loop");
  while(1) {
    static short server_end;
    show_notification(server_mode, 3);
    PRINTR("1");
    DELAY_2000;
    server.on ("/", HTTP_GET, [](AsyncWebServerRequest * request) {
      request->send_P(200, "text/html", index_html);
    });
    server.on ("/get", HTTP_GET, [] (AsyncWebServerRequest * request) {
      String inputssid;
      String inputpass;
      String inputpro;
      String inputloc;
      String inputdev;
      String inputpk;
      String inputreg;
      /* ToDo: make structure of key values and array of it */
      if (request->hasParam("WIFI_NAME")) {
        inputssid = request->getParam("WIFI_NAME")->value() + "\0";       
        PRINTS("WIFI-NAME");
        PRINTR(inputssid);
      }
      if (request->hasParam("PASS")) {
        inputpass = request->getParam("PASS")->value() + "\0";
        PRINTS("PASS");
        PRINTR(inputpass);
      }
      if (request->hasParam("PROJECT_ID")) {
        inputpro = request->getParam("PROJECT_ID")->value() + "\0";
        PRINTS("PROJECT-ID");
        PRINTR(inputpro);
      }
      if (request->hasParam("LOCATION")) {
        inputloc = request->getParam("LOCATION")->value() + "\0";
        PRINTS("Location");
        PRINTR(inputloc);
      }
      if (request->hasParam("DEVICE_ID")) {
        inputdev = request->getParam("DEVICE_ID")->value() + "\0";
        PRINTS("DEVICE_ID");
        PRINTR(inputdev);
      }
      if (request->hasParam("PRIVATE_KEY")) {
        inputpk = request->getParam("PRIVATE_KEY")->value()  + "\0";
        PRINTS("PRIVATE-KEY");
        PRINTR(inputpk);
      }
      if (request->hasParam("REGISTRY_ID")) {
        inputreg = request->getParam("REGISTRY_ID")->value() + "\0";
        PRINTS("REGISTRY_ID");
        PRINTR(inputreg);
        server_end = 1;   
      }
      vars = String("{\"ssid\":\"" )+ inputssid +\
              String("\",\"pass\":\"") + inputpass +\
              String("\",\"project_id\":\"") + inputpro +\
              String("\",\"location\":\"") + inputloc +\
              String("\",\"dev\":\"") + inputdev +\
              String("\",\"private_key\":\"") + inputpk +\
              String("\",\"reg_id\":\"") + inputreg +\
              String("\"}");
      PRINTR(vars);
      request->send(200, "text/html", "ok");
    });
    server.onNotFound(not_found);
    server.begin();
    if (server_end) {
      server_end = 0;
      server.end();
      const char *server_data = vars.c_str();
      nv_write(SPIFFS, data_file, server_data);
      break;
    }
  }
}