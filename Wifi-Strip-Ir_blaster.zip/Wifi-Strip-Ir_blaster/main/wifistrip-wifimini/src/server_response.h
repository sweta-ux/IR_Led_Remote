/******************************************************************************
 * Copyright 2020 IndiaSells
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *****************************************************************************/
#ifndef SERVER_RESPONSE_H
#define SERVER_RESPONSE_H

#include "ota.h"
#include "soc/timer_group_struct.h"
#include "soc/timer_group_reg.h"
#include <IRremoteESP8266.h>
#include <IRsend.h>

/* ESP GPIO pin to use. Recommended: 4 (D2) */
const uint16_t kIrLed = 4;

void receive_from_server(void *);
void update_relay(int r, uint8_t pin);
void send_to_server_periodically(void *pvParameters);
void message_received(String & , String &);
void check_temp_weather(void);
void check_cmd(int, String, String, String, String, int, bool, bool);
void check_temp_weather (const char*, const char*, const char*, const char*, const char*, struct temp_weather_def *);
void generate_interrupt(void);
void toggle_relay(int);
void periodic_response_send(bool, bool);
String check_per_int(bool, int);
bool publish_telemetry(String);
bool publish_on_response(String);
bool publish_on_periodic(String);
bool publish_on_delete(String);
String relays_response(bool, int, bool);
String IR_response(bool, int);
String delete_response(int);
void send_json();
void IR_Send(int,uint32_t);

/*
 *struct relay_def - define the structure for the relays
 */
struct relay_def {  
  String name;
  int state;
  bool flag;
};

/*
 *struct temp_weather_def- define the structure of the weather
 */
struct temp_weather_def {
  String temp_Str;
  String temp_minStr;
  String temp_maxStr;
  String desc;
  String icon;
};

#endif