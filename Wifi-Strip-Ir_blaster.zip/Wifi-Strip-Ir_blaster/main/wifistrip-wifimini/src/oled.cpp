#include "OLEDDisplayUi.h"
#include "images.h"
#include "font.h"
#include "SSD1306.h"
#include "oled.h"
#include "ArduinoJson.h"
#include "server_response.h"
#include "definitions.h"
#include "hardware.h"

#define SDA_PIN 21 // GPIO21 -> SDA
#define SCL_PIN 22 // GPIO22 -> SCL
#define SSD_ADDRESS 0x3c

SSD1306  display(SSD_ADDRESS, SDA_PIN, SCL_PIN);
OLEDDisplayUi ui (&display);

/* Extern weather structure */
extern struct temp_weather_def _weather;
extern  struct watt_current consumption;


/* Define global variables */
bool oled_inactive;
int count = 0;
int touch_count = 0;
unsigned long lastmillis, read_millis = 0;
bool on_flag = false;

/**
 * oled_init - initialised oled if oled not initialised led will indicate
 * args: void
 * return: int
 */
void oled_init() {
  if (!display.init()) {
    show_error();
    /* Update a global variable for OLED_AVAIL*/
    oled_inactive = true;
  } else {
    notify_msg(start_msg);
    setup_ui();
    show_success();
    oled_inactive = false;
  }
}

/**
 * oled_on_off- task of on_off of the oled
 * args: void *pv UNUSED
 * return: void
 */
void oled_led_on_off(void *pv) {
  #ifdef WIFISTRIP
    PRINTS("OLED_LED_ON_OFF running on core ");
    PRINTR(xPortGetCoreID());
    for(;;) {
      TIMERG0.wdt_wprotect = TIMG_WDT_WKEY_VALUE;
      TIMERG0.wdt_feed=1;
      TIMERG0.wdt_wprotect=0;
      if (oled_inactive == false) { /* if oled initialised then this function work */
        int input_value = touchRead(OLED_RESET);
        unsigned long currentmillis = millis();
        if ((input_value <= 17)) {
          count++;
        }
        if ((count >= 3) && (input_value <= 17)) {
          touch_count++;
          count = 0;
        } else if((count <= 3) && (input_value >= 17)) {
          count = 0;
        }
        
        /* count for OLED ON OFF */
        if ((touch_count == 10) && (input_value <= 17) && (on_flag == false)) {
          display.displayOff();
          on_flag = true;
        } else if ((touch_count >= 15) && (input_value <= 17) && (on_flag == true)) {
          Serial.println("oled onn");
          DELAY_1000;
          display.displayOn();
          display.clear();
          on_flag = false;
        }

        if ((currentmillis - lastmillis > 100) && (input_value >= 17) && (touch_count > 4)) {
          PRINTR("count id zero");
          touch_count = 0;
          lastmillis = currentmillis;
        }
        
        /* count for Night Lamp */
        #ifdef WIFISTRIP
          if ((touch_count == 1) && (input_value >= 17)) {
            analogWrite(NIGHT_LAMP, 50);
          } else if ((touch_count == 2) && (input_value >= 17)) {
            analogWrite(NIGHT_LAMP, 150);
          } else if ((touch_count == 3) && (input_value >= 17)) {
            analogWrite(NIGHT_LAMP, 255);
          } else if ((touch_count == 4) && (input_value >= 17)) {
            analogWrite(NIGHT_LAMP, 0);
            touch_count = 0;
          }
        #endif
        DELAY_100;
      } else {
        return; /* if oled not initialised then return blank */
      }
    }
    DELAY_1000;
  #endif
}

/**
 * notify_msg - display meassages on oled
 * args: string msg
 * return: void
 */
void notify_msg(String msg) {
  #ifdef OLED
  if (oled_inactive) { /* oled not initialised */
    return; //show_error();
  } else {
    display.clear();
    display.setTextAlignment(TEXT_ALIGN_LEFT);
    display.setFont(ArialMT_Plain_16); // set a font
    display.drawString(10, 25,  msg);
    display.display();
    DELAY_100;
  }
  #endif
}

/**
 * wifi_strength - measuring th estrength of the wifi
 * args: void
 * return: void
 */
int wifi_strength(void) {
  long rssi = WiFi.RSSI();
  int bars;
  if (rssi > -55) { 
    bars = 5;
  } else if ((rssi < -55) & (rssi > -65)) {
    bars = 4;
  } else if ((rssi < -65) & (rssi > -70)) {
    bars =3;
  } else if ((rssi < -70) & (rssi > -78)) { 
    bars = 2;
  } else if ((rssi < -78) & (rssi > -82)) {
    bars = 1;
  } else {
    bars = 0;
  }
  return bars;
}

/**
 * display_bar - display wifi graph on oled
 * args: void
 * return: void
 */
void display_bar() {
  #ifdef OLED
  if (!oled_inactive) { 
    int bars = wifi_strength();
    if (bars >= 4) {
      display.drawCircleQuads(110, 15, 13, 0b00000001);
      display.drawCircleQuads(110, 15, 14, 0b00000001);
    }

    if (bars >= 2) {
      display.drawCircleQuads(110, 15, 9, 0b00000001);
      display.drawCircleQuads(110, 15, 10, 0b00000001);
    }
    
    if (bars >= 1) {
      display.drawCircleQuads(110, 15, 5, 0b00000001);
      display.drawCircleQuads(110, 15, 6, 0b00000001);
      display.drawCircleQuads(110, 15, 1, 0b00000001);
      display.drawCircleQuads(110, 15, 2, 0b00000001);
    }
    display.drawCircleQuads(110, 15, 5, 0b00000001);
    display.drawCircleQuads(110, 15, 6, 0b00000001);
    display.drawCircleQuads(110, 15, 1, 0b00000001);
    display.drawCircleQuads(110, 15, 2, 0b00000001);
  } else {
    return;
  }
  #endif
}

/**
 * display_wifi_name - display wifi ssid on oled
 * args: String msg, String wifi_name, int column, int row
 * return: void
 */
void display_wifi_name(String msg, int column, int row, String wifi_name, int column1, int row1) {
  #ifdef OLED
  if (!oled_inactive) {
    display.clear();
    display.setTextAlignment(TEXT_ALIGN_LEFT);
    display.setFont(ArialMT_Plain_16); // set a font
    display.drawString(column, row, msg);
    display.drawString(column1, row1,  wifi_name);
    display.display();
  }
  #endif
}

void msOverlay(OLEDDisplay *display, OLEDDisplayUiState* state) {
  #ifdef OLED
  //  display->setTextAlignment(TEXT_ALIGN_CENTER); 
  //  display->setFont(ArialMT_Plain_16);
  //  display->drawString(128,0,"APPLE");
  #endif
}

/**
 * draw_frame_1 - frame 1 of oled having Time, Date, Day
 * args: oledDisplay *, OledDisplayUiState* int16_t, int16_t
 * ret: void 
 */
void draw_frame_1(OLEDDisplay *display, OLEDDisplayUiState* state, int16_t x, int16_t y) {
  #ifdef OLED
  if (!oled_inactive) {
    char *nday_day = ntp_day();
    char *nday_date = ntp_date();
    char *ntime = ntp_time();

    /*display day */
    display->setTextAlignment(TEXT_ALIGN_LEFT);
    display->setFont(Lato_Bold_10);
    display->drawString(10 + x, 0 + y, nday_day);
    
    /*display date */
    display->setTextAlignment(TEXT_ALIGN_CENTER);
    display->setFont(Lato_Bold_10);
    display->drawString(85 + x, 0 + y, nday_date);

    /*display Time */
    display->setFont(Lato_Bold_20);
    display->drawString(64 + x, 25 + y, ntime);
    display->setTextAlignment(TEXT_ALIGN_LEFT);
  } else {
    return;
  }
  #endif
}

/**
 * draw_frame_2 - frame 2 of oled having weather_Description, Temp, Temp max and min
 * args: oledDisplay *, OledDisplayUiState* int16_t, int16_t
 * ret: void 
 */
void draw_frame_2(OLEDDisplay *display, OLEDDisplayUiState* state, int16_t x, int16_t y) {
  #ifdef OLED
  if (!oled_inactive) {
    // weather icon with weather description
    // sunny weather 
    if (  _weather.icon == "01d" || _weather.icon == "01n") {
      display->drawXbm(0 + x, 0 + y, Logo_01d_width, Logo_01d_height, Logo_01d_bits);
    }

    // cloudy weather 
    if ( _weather.icon == "02d" || _weather.icon == "02n" || _weather.icon == "03d" || _weather.icon == "03d" || _weather.icon == "04d" || _weather.icon == "04n") {
      display->drawXbm(0 + x, 0 + y, Logo_03d_width, Logo_03d_height, Logo_03d_bits);
    }

    // Rainy weather
    if ( _weather.icon == "09d" || _weather.icon == "09n" || _weather.icon == "10d" || _weather.icon == "10n" || _weather.icon == "11d" || _weather.icon == "11n" || _weather.icon == "50d") {
      display->drawXbm(0 + x, 0 + y, Logo_10d_width, Logo_10d_height, Logo_10d_bits);
    }
      
    display->setTextAlignment(TEXT_ALIGN_LEFT); 
    display->setFont(Lato_Bold_10);
    display->drawString(55 + x,0 + y , _weather.desc);
    display->setFont(Lato_Bold_14);
    display->drawString(55 + x,20 + y, _weather.temp_Str + "°C");
    display->setFont(Lato_Regular_10);
    display->drawString(55+ x, 40 + y, _weather.temp_minStr + "°C / " + _weather.temp_maxStr + "°C");
  } else {
    return;
  }
  #endif
}

/**
 * draw_frame_3 - frame 3 of oled having status, wifi_strength
 * args: oledDisplay *, OledDisplayUiState* int16_t, int16_t
 * ret: void 
 */
void draw_frame_3(OLEDDisplay *display, OLEDDisplayUiState* state, int16_t x, int16_t y) {
  #ifdef OLED
  if (!oled_inactive) {
    display->clear();
    display->setFont(Lato_Bold_14);
    display->drawString(0 + x, 20 + y, "Status:");
    display->setFont(Lato_Bold_14);
    display->drawString(45 + x,20 + y,  "OK");

    int bars = wifi_strength();
    if (bars >= 4) {
      display->drawCircleQuads(110, 15, 13, 0b00000001);
      display->drawCircleQuads(110, 15, 14, 0b00000001);
    }

    if (bars >= 2) {
      display->drawCircleQuads(110, 15, 9, 0b00000001);
      display->drawCircleQuads(110, 15, 10, 0b00000001);
    }
    
    if (bars >= 1) {
      display->drawCircleQuads(110, 15, 5, 0b00000001);
      display->drawCircleQuads(110, 15, 6, 0b00000001);
      display->drawCircleQuads(110, 15, 1, 0b00000001);
      display->drawCircleQuads(110, 15, 2, 0b00000001);
    }
    display->drawCircleQuads(110, 15, 5, 0b00000001);
    display->drawCircleQuads(110, 15, 6, 0b00000001);
    display->drawCircleQuads(110, 15, 1, 0b00000001);
    display->drawCircleQuads(110, 15, 2, 0b00000001);
  } else {
    return;
  }
  #endif
}

/**display_wattage - display Wattage across relay On
 * args: String msg, String wifi_name, int column, int row
 * return: void
 */
void draw_frame_4(OLEDDisplay *display, OLEDDisplayUiState* state, int16_t x, int16_t y) {
  #ifdef OLED
  if (!oled_inactive) {
    //float Current,watt = cal_current();
    float Current = consumption.current;
    float watt = consumption.watt;
    display->clear();
    display->setFont(Lato_Bold_14);
    display->drawString(0 + x, 0 + y, "Current:");
    display->setFont(Lato_Bold_14);
    display->drawString(50 + x,0 + y,  String(Current));
    display->setFont(Lato_Bold_14);
    display->drawString(80 + x, 0 + y, "A");
    display->setFont(Lato_Bold_14);
    display->drawString(0 + x, 20 + y, "Wattage:");
    display->setFont(Lato_Bold_14);
    display->drawString(60 + x,20 + y, String(watt));
    display->setFont(Lato_Bold_14);
    display->drawString(95 + x,20 + y, "W");
  }
  #endif
}

FrameCallback frames[] = {draw_frame_1, draw_frame_2, draw_frame_3, draw_frame_4};

int frameCount = 4;

OverlayCallback overlays[] = {msOverlay};
uint8_t overlaysCount = 1;

/**
 * setup_ui- setting frame ui of the oled
 * args: void
 * ret: void
 */
void setup_ui(void) {
  #ifdef OLED
  ui.setTargetFPS(90);
  ui.setActiveSymbol(activeSymbol);
  ui.setInactiveSymbol(inactiveSymbol);
  ui.setIndicatorPosition(BOTTOM);
  ui.setIndicatorDirection(LEFT_RIGHT);
  ui.setFrameAnimation(SLIDE_LEFT);
  ui.setFrames(frames, frameCount);
  ui.setOverlays(overlays, overlaysCount);
  ui.init();
  display.flipScreenVertically();
  #endif
}

/**
 * oled_frame- updating the frame 
 * args: void
 * ret: void
 */
void oled_frame(void) { 
  #ifdef OLED
  if (!oled_inactive) {
    int remainingTimeBudget = ui.update();
    if (remainingTimeBudget > 0) {
      delay(remainingTimeBudget);
    }
  } else {
    return;
  }
  #endif
}

/**
 * show_notification- handling oled notification and error on led 
 * args: String, int
 * ret: void
 */
void show_notification (String msg, int led) {
  #ifdef OLED
  if (msg != "\0") {
    notify_msg(msg);
  } else {
    // discard msg
  }
  #endif
  switch (led) {
    case 1: /* constant-expression */
      show_error();  /**/
      break;
    case 2:
      show_hardware_error();  /**/
      break;
    case 3:
      show_web_server();    /**/
      break;
    case 4:
      connecting_wifi();    /**/
      break;
    case 5:
      wifi_connecting_error();   /**/
      break;
    case 6:
      show_success();      /**/
      break;
    case 7:
      show_clear_nv();  /**/
      break;
    case 8:
      show_nv_error();   /**/
      break;
    default:
      break;
  }
}