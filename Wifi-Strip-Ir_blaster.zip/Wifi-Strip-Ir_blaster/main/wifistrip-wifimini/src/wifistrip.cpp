/******************************************************************************
 * Copyright 2020 IndiaSells
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *****************************************************************************/
/* Defining The Libraries */
#include "cloud.h"
#include "apmode.h"
#include "ntp.h"
#include "server_response.h"
#include "offline_server.h"
#include <EEPROM.h>

#ifdef POWER_MEASUREMENT
#include "EmonLib.h"
#endif

struct cloud_def _config = {0}; /* make it heap memory */
struct relay_def *relay;

#ifdef POWER_MEASUREMENT
EnergyMonitor emon1;
#endif


/**
 * setup - 
 */
void setup() {
  Serial.begin(115200);
  /* Resetting wifimini using main power supply on off */
  #ifdef HARD_RESET
  EEPROM.begin(512);
  int b = EEPROM.read(0);
  PRINTR("\n");
  PRINTR(b);
  PRINTR("\n");
  if (b == 5) {
    clear_nv();
    EEPROM.write(0, 0);
    EEPROM.commit();
    delay(1000);
  } else {
    EEPROM.write(0, ++b);
    EEPROM.commit();
    delay(1000);
  }
  #endif

  #ifdef POWER_MEASUREMENT
  emon1.current(ACS_CURRENT, 18);
  #endif

  int counter = 0;
  int ret;

  /* Initialise controller hardware */
  ret = init_hardware();
  if (ret != SUCCESS) {
    while(1) {
      /* stuck in while, if getting error in hardware */
      show_notification(memory_error, 8);
    }
  }
  
  /* Define the memory size of the structure */
  relay = (struct relay_def *)malloc(sizeof(struct relay_def) * (NUM_RELAYS + 1));
  if (!relay) {
    PRINTR(hardware_error);
    /* ToDo
      error handling with oled */ // no need to show on oled, it's not userfull information
  } else {
    memset(relay, 0, sizeof(struct relay_def) * (NUM_RELAYS + 1));
  }
  
  #ifdef WIFIMINI_AC_SWITCH
  /* task for AC_Switch and toogle the relays */
  xTaskCreatePinnedToCore(hard_switch, "TOGGLE_AC_SWITCH", 10000, NULL, 0, NULL, 0);
  #endif

  /* task for factory reset and toogle the relays */
  xTaskCreatePinnedToCore(reset_and_toggle_relays, "RESET_AND_TOGGLE_RELAYS", 10000, NULL, 0, NULL, 0);
   
  #ifdef WIFIPLATE_TACT_PIN
  /* task for toggle the relays using tact switch*/
  xTaskCreatePinnedToCore(tac_switch, "Switch_on_off_AND_TOGGLE_RELAYS", 10000, NULL, 0, NULL, 0);
  #endif

  #ifdef WIFIPLATE_TOUCH_PIN
  /* task for toggle the relays using touch switch*/
  xTaskCreatePinnedToCore(touch_switch, "Switch_on_off_AND_TOGGLE_RELAYS", 10000, NULL, 0, NULL, 0);
  #endif

  #ifdef POWER_MEASUREMENT
  xTaskCreatePinnedToCore(cal_current, "calculate_power", 10000, NULL, 0, NULL, 0);
  #endif

  #ifdef OLED
  xTaskCreatePinnedToCore(oled_led_on_off, "OLED_LED_ON_OFF", 10000, NULL, 0, NULL, 0); //TODO:Change name
  #endif

  /* Interrupt for sending the data to cloud */
  attachInterrupt(digitalPinToInterrupt(JSON_INTERRUPT), send_json, FALLING);

restart_ap_mode:
  do {
    /* Validate the NV For the controller */
    ret = validate_nv(&_config);
    if (ret != SUCCESS) {
      /* Display msg on OLED */
      show_notification(no_data_in_nv, 2);
      enter_ap_mode();
      continue;
    }
    
    /* wifi Initialization
      Not checked for error as global variable would
      set against this.*/
    while (counter < 10) {
      wifi_start(&_config);
      counter ++;
      
      ret = check_wifi();
      if (ret != FAILURE)
        break;
    }

    while (counter >= 10) {
      /* if checking for wifi exceed 10 times then reset the hardware
        blink red led and display msg on OLED */
      show_notification(reset_device, 1);
    }
    //setup_routing();

    /* Assuming check_wifi has updated its return into 'ret'*/
    if (ret != FAILURE)
      break;
      
    ret = validate_nv(&_config);
  } while(1);

  /* once connected with the router begin offline_server */
  setup_routing();

  /* Initialise NTP server for fecthing date and time */
  #ifdef NTP
  ret = init_ntp();
  if (ret != SUCCESS) {
    PRINTR("TIME NOT SET");
  }
  #endif

  /* Set_up cloud_connection configuration */
  ret = setup_iot_cloud(&_config);
  if (ret != SUCCESS) {
    goto restart_ap_mode;
  }

  /* Task for handling offline server */
  xTaskCreatePinnedToCore(handle_offline_server, "START_OFF_LINE", 10000, NULL, 0, NULL, 1);
  
  /* Task for receving msg from cloud */
  xTaskCreatePinnedToCore(receive_from_server, "RECEIVE_FROM_SERVER", 10000, NULL, 0, NULL, 0);

  /* Task for sending msg to cloud */
  xTaskCreatePinnedToCore(send_to_server_periodically, "SEND_TO_SERVER", 10000, NULL, 0, NULL, 1);
  #ifdef LOGS
  char *date = ntp_date();
  char *time = ntp_time();
  PRINTR(date);
  PRINTR(time);
  String date_time = String((date)) +","+ String((time));
  append_data(date_time, "R");
  #endif
}

/**
 * 
 */
void loop() {
  #ifdef HARD_RESET
  // resetting EEPROM restart counter
  EEPROM.write(0, 0);
  EEPROM.commit();
  DELAY_300;
  #endif

  #ifdef OLED
  oled_frame();
  //DELAY_1000;
  #endif
  check_mqtt_reconnect();
  DELAY_1000;
}