/******************************************************************************
 * Copyright 2020 IndiaSells
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *****************************************************************************/
#ifndef _HARDWARE_H
#define _HARDWARE_H

#include <analogWrite.h>
#include "definitions.h"
#include "oled.h"


struct watt_current {
  float current;
  float watt;
};

/* Pin Definition of Pheripherals*/
#define Red 23
#define Green 26
#define Blue 27
#define R1 13
#define R2 14
#define R3 15
#define JSON_INTERRUPT 18
#define HARD_RESET_BUTTON 12

#ifdef WIFISTRIP_PINS
#define NIGHT_LAMP 2
#define USB 19
#define OLED_RESET 4
#endif

#ifdef WIFIMINI_PINS
#define R4 19
#endif

#ifdef WIFIPLATE_PINS 
#define R4 19
#define R5 2
#define R6 4
#define R7 16
#define R8 25
#endif

#ifdef WIFIMINI_8_PINS
#define R5 2
#define R6 4
#define R7 16
#define R8 25
#endif

#ifdef POWER_MEASUREMENT
#define ACS_CURRENT 35
#endif

/* declaration of the function */
void RGB_color(int , int, int);
void show_error(void);
void show_hardware_error();
void connecting_wifi();
void show_clear_nv(void);
void show_nv_error(void);
void show_success(void);
void show_web_server(void);
void wifi_connecting_error(void);
void init_gpio_pins(void);
int init_hardware(void);
void reset_and_toggle_relays(void *);
void hard_switch(void *pvParameters);
void tac_switch(void *pvParameters);
void calculate_power(void *);
float getVPP(void);
//float cal_current(void);
void cal_current(void *);
void touch_switch(void *pvParameters);

#endif