#include <WiFiClientSecure.h>
#include <Client.h>
#include <MQTT.h>
#include <iotmqtt.h>
#include <CloudCore.h>
#include "cloud.h"
#include "apmode.h"
#include "definitions.h"
#include "server_response.h"
#include "ArduinoJson.h"
#include "MQTTClient.h"

/* declaring object of the class */
Client *netClient;
iotdevice *device;
iotmqtt *mqtt;
MQTTClient mqttClient(720);

boolean skip;
const char *cloud_device_id;

/* extern structure */
extern struct cloud_def _config;

int ret;

/**
 * start_wifi-> initialising wifi
 * args: void
 * returns: int
 */
void wifi_start(struct cloud_def *_config) {
  if (WiFi.status() != WL_CONNECTED) {
    WiFi.begin( _config->wifi_ssid, _config->wifi_pass );
    show_notification(wifi_connecting, 4);
    DELAY_1000;
    #ifdef OLED
    display_wifi_name("SSID: ", 5, 20, _config->wifi_ssid, 5, 40);
    #endif
    PRINTS("IP Address: ");
    Serial.println(WiFi.localIP());
    #ifdef NTP
    configTime(0, 0, "pool.ntp.org", "time.nist.gov");
    #endif
    DELAY_100;
  }
}

String check_ip() {
  String ip_addr = WiFi.localIP().toString().c_str();;
  //PRINTR(ip_addr);
  return ip_addr;
}
/**
 * start_wifi - enable wifi when SSID/Pass is available
 * args: void
 * return: int
 */
int check_wifi(void) {
  WiFi.mode(WIFI_STA);
  DELAY_100;
  uint8_t i = 0;
  while ((WiFi.status() != WL_CONNECTED) && (i <= 20)) {
    PRINTS(".");
    show_notification("", 5);
    if ((++i % 20) == 0) {
      return FAILURE;     
    }
  }
  show_notification("", 6); /* green color led will blink */
  return SUCCESS;
}

/**
 * getjwt-> getting jwt as in string 
 * args: null
 * returns: string
 */
String getJwt() {    
/* Time (seconds) to expire token += 20 minutes for drift*/
/* Maximum 24H (3600*24) */
  const int jwt_exp_secs = 3600*24;
  unsigned long iat = time(nullptr);
  PRINTR("Refreshing JWT");
  String jwt = device->createJWT(iat, jwt_exp_secs);
  //PRINTR(jwt);
  return jwt;
}

/**
 *publish_state-> method for sending data on state topic
 * args: String data
 * returns: bool
 **/
bool publish_state(String data) {
  return mqtt->publishState(data);
}

/** 
 * mqtt_connect-> connect with mqtt 
 * args: bool skip
 * returns: int
 */
int mqtt_connect(bool skip) {
  int __backoff__ = 1000; // current backoff, milliseconds
  static const int __factor__ = 2.5f;
  static const int __minbackoff__ = 1000; // minimum backoff, ms
  static const int __max_backoff__ = 60000; // maximum backoff, ms
  static const int __jitter__ = 500; // max random jitter, ms
  PRINTR("Connecting...");
  bool keepgoing = true;
  if (keepgoing) {
    DELAY_100;
    bool result = mqttClient.connect( device->getClientId().c_str(), "unused", getJwt().c_str(), skip);
    DELAY_100;
    if (mqttClient.lastError() != LWMQTT_SUCCESS && result) {
      ret = log_error();
      if (ret != 0) {
        PRINTR(ret);
      }
      ret = log_return_code();
      if (ret != 0) {
        PRINTR(ret);
      }
      if (__backoff__ < __minbackoff__) {
        __backoff__ = __minbackoff__;
      }
      __backoff__ = (__backoff__ * __factor__) + random(__jitter__);
      if (__backoff__ > __max_backoff__) {
        __backoff__ = __max_backoff__;
      }
      // Clean up the client
      mqttClient.disconnect();
      skip = false;
      PRINTR("Delaying " + String(__backoff__) + "ms");
      delay(__backoff__);
      keepgoing = true;
    } else {
      PRINTR(mqttClient.connected() ? "connected" : "not connected");
      if (!mqttClient.connected()) {
        int ret = log_error();
        if (ret != 0) {
          PRINTR(ret);
        }
        ret = log_return_code();
        if (ret != 0) {
          PRINTR(ret);
        }
        PRINTR("Retrying to connect");
        show_notification(mqtt_disconnect, 2);
        mqttClient.disconnect();
        skip = false;
        keepgoing = true;
        #ifdef LOGS
        char *date = ntp_date();
        char *time = ntp_time(); 
        String date_time = String((date)) + String((time));
        append_data(date_time, "M_D");  /*MQTT DISCONECTION*/
        #endif
        PRINTR("Waiting 60 seconds");
        delay(__max_backoff__);
      } else {
        // We're now connected
        PRINTR("\nLibrary connected!");
        keepgoing = false;
        __backoff__ = __minbackoff__;
        send_device_info();
        DELAY_100;
        periodic_response_send(false, true);
        DELAY_100;
      }
    }
  }
  return ret;
}

/**
 * send_device_info:- check mqtt connection an dsend device configuration.
 * args:- void
 * ret:- void
 */
void send_device_info (void) {
  if (mqttClient.connected()) {
    /* sending device_config on state topic */
    mqttClient.subscribe(device->getCommandsTopic(), 0);
    mqttClient.subscribe(device->getConfigTopic(), 1);
    String on_connect = device_info();
    PRINTR(on_connect);
    publish_state(on_connect);
  }
}

/**
 * device_info:- information of device with mac-add
 * args:- void
 * ret:- void
 */
String device_info() {
  String ip_addr = check_ip();
  DynamicJsonBuffer jsonBuffer(300);
  JsonObject& device_config = jsonBuffer.createObject();
  device_config["device_id"] = _config.cloud_device_id;
  device_config["mac_address"] = String(mac_address());
  device_config["version"] = String(code_version);
  device_config["ap_mode_id"] = String(device_name());
  device_config["status"] = String(state_cmd);
  device_config["ip_address"] = String(ip_addr);
  JsonArray& meta = device_config.createNestedArray("meta");
  #if defined (WIFIMINI) || defined (WIFIMINI_8_RELAY) || defined (WIFIPLATE)
  meta.add("");
  #endif

  #ifdef WIFISTRIP
  meta.add("weather");
  #endif
  String device;
  device_config.printTo(device);
  return device;
}

/**
 * connect-> connect with wifi and mqtt
 * args: void
 * ret: int
 */
void connect() {
  int ret = check_wifi();
  if (ret != SUCCESS) {
    wifi_start(&_config);
  }
  DELAY_100;
  ret = mqtt_connect(skip);
  PRINTR(ret);
  if (ret != 0) {
    setup_iot_cloud(&_config);
    PRINTR("not connect with mqtt");
  }
}

/**
 * start_mqtt-> initialized mqtt 
 * args: void
 * ret: int
 */
void start_mqtt() {
  //boolean enabled;
  boolean useLts = true;
  boolean enabled = useLts;
  mqttClient.begin(enabled ? MQTT_HOST_LTS : MQTT_HOST,MQTT_PORT, *netClient);
}

/**
 * setup_iot_cloud-> initalized cloud
 * args: void
 * ret: void
 */
int setup_iot_cloud(struct cloud_def *_config) {
  device = new iotdevice(_config->cloud_project_id, _config->cloud_location, _config->cloud_registry_id, _config->cloud_device_id, _config->cloud_private_key);
  cloud_device_id = _config->cloud_device_id;
  netClient = new WiFiClientSecure();
  if (!netClient) {
    return FAILURE;
  }
  //mqttClient = new MQTTClient(512);
  //MQTTClient mqttClient(512) = new MQTTClient(512);
  /*if (!mqttClient) {
    //Release netClient 
    mqttClient = NULL;
    return FAILURE;
  }*/
  mqttClient.setOptions(5, true, 1000); // keepAlive, cleanSession, timeout
  mqtt = new iotmqtt(&mqttClient, netClient, device);
  if (!mqtt) {
    /* Release mqttClient, netClient */
    //mqttClient = NULL;
    netClient = NULL;
    return FAILURE;
  }
  mqtt->setUseLts(true);
  start_mqtt();
  return SUCCESS;
}

/**
 * reconnect-> reconnect with wifi and mqtt
 * args: void
 * ret: void
 */
void check_mqtt_reconnect() {
  //PRINTR("checking mqtt");
  mqtt->loop();
  DELAY_1000;  
  if (!mqttClient.connected()) {
    connect();
  }
}

/**
 * log_error-> returning mqtt error while connecting with mqtt
 * args: void
 * ret: int
 */
int log_error(void) {
  int error2 = mqttClient.lastError();
  if (error2 == 0) {
    PRINTS("LWMQTT_SUCCESS");
  } else if (error2 == -1) {
    PRINTS("LWMQTT_BUFFER_TOO_SHORT");
  }else if (error2 == -2) {
    PRINTS("LWMQTT_VARNUM_OVERFLOW"); 
  } else if (error2 == -3) {
    PRINTS("LWMQTT_NETWORK_FAILED_CONNECT");
  } else if (error2 == -4) {
    PRINTS("LWMQTT_NETWORK_FAILED_READ");
  } else if (error2 == -5) {
    PRINTS("LWMQTT_NETWORK_FAILED_WRITE");
  } else if (error2 == -6) {
    PRINTS("LWMQTT_REMAINING_LENGTH_OVERFLOW");
  } else if (error2 == -7) {
    PRINTS("LWMQTT_REMAINING_LENGTH_MISMATCH");
  } else if (error2 == -8) {
    PRINTS("LWMQTT_MISSING_OR_WRONG_PACKET");
  } else if (error2 == -9) {
    PRINTS("LWMQTT_CONNECTION_DENIED");
  } else if (error2 == -10) {
    PRINTS("LWMQTT_FAILED_SUBSCRIPTION");
  } else if (error2 == 11) {
    PRINTS("LWMQTT_SUBACK_ARRAY_OVERFLOW");
  } else if (error2 == -12) {
    PRINTS("LWMQTT_PONG_TIMEOUT");
  }
  return error2;
}

/**
 * log_return_code-> returning mqtt error while connecting with mqtt
 * args: void
 * ret: int
 */
int log_return_code(void) {
  int error1 = mqttClient.returnCode();
  if (error1 == 0) {
    PRINTS("LWMQTT_CONNECTION_ACCEPTED");
  } else if (error1 == -1) {
    PRINTS("LWMQTT_UNACCEPTABLE_PROTOCOL");
  } else if (error1 == -2) {
    PRINTS("LWMQTT_IDENTIFIER_REJECTED");
  } else if (error1 == -3) {
    PRINTS("LWMQTT_SERVER_UNAVAILABLE");
  } else if (error1 == -4) {
    PRINTS("LWMQTT_BAD_USERNAME_OR_PASSWORD");
  } else if (error1 == -5) {
    PRINTS("LWMQTT_NOT_AUTHORIZED");
  } else if (error1 == -6) {
    PRINTS("LWMQTT_UNKNOWN_RETURN_CODE");
  }
  return error1;
}