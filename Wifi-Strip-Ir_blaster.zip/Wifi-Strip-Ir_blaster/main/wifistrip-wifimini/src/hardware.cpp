#include "hardware.h"
#include "nv.h"
#include "cloud.h"
#include "server_response.h"
#include "oled.h"
#include "EmonLib.h"

extern EnergyMonitor emon1;

extern struct relay_def *relay;

#ifdef WIFIPLATE_PINS
const int pushbutton[] ={17,32,33,34};// define push button inputs
#endif

#ifdef WIFIMINI_AC_SWITCH
const int input_switch[] ={2,16,17,25};// define push button inputs
#endif

#ifdef POWER_MEASUREMENT
float wattage;
float avg_wattage;
char x[8];
#endif

/**
 * set RGB color
 * args: void
 * return: void
 */
void RGB_color(int red_light_value, int green_light_value, int blue_light_value) {
  analogWrite(Red, red_light_value);
  analogWrite(Green, green_light_value);
  analogWrite(Blue, blue_light_value);
}

/**
 * show_error - red led blink
 * args: void
 * return: void
 */
void show_error() {
  RGB_color(255, 0, 0); // Red
  DELAY_100;
  RGB_color(0, 0, 0); 
  DELAY_100;
}

/**
 * show_hadware_error - Blink Red Led with 5sec delay
 * args: String, int
 * ret: void
 */
void show_hardware_error() {
  RGB_color(255, 0, 0); // Red
  DELAY_5000;
  RGB_color(0, 0, 0); 
  DELAY_5000;
}

/**
 * connecting_wifi - Blink Green Led with 5sec delay
 * args: String, int
 * ret: void
 */
void connecting_wifi() {
  RGB_color(0, 255, 0); 
  DELAY_100;
  RGB_color(0, 0, 0); 
  DELAY_100;
}
/**
 * show_error - show error based on led
 * args: void
 * return: void
 */
void show_clear_nv() {
  /* orange led blink */
  RGB_color(255, 165, 0);
  DELAY_1000;
}

/**
 * show_error -  yellow led blink 
 * args: void
 * return: void
 */
void show_nv_error() {
  RGB_color(255, 204, 0);
  DELAY_100;
  RGB_color(255, 204, 0);
  DELAY_100;
}

/**
 * show success - green led blink
 * args: void
 * return: void
 */
void show_success() {
  RGB_color(0, 255, 0); 
  DELAY_100;
  RGB_color(0, 0, 0); 
  DELAY_100;
}

/**
 * show success - blue led blink
 * args: void
 * return: void
 */
void show_web_server() {
  RGB_color(0, 0, 255); 
  DELAY_100;
  RGB_color(0, 0, 0); 
  DELAY_100;
}
/**
 * show success - tri color led blink
 * args: void
 * return: void
 */
void wifi_connecting_error() {
  RGB_color(0, 0, 255); 
  DELAY_100;
  RGB_color(0, 0, 0); 
  DELAY_100; /* BLUE */
  RGB_color(0, 255, 0); 
  DELAY_100;
  RGB_color(0, 0, 0); 
  DELAY_100; /* GREEN */
  RGB_color(255, 0, 0);
  DELAY_100;
  RGB_color(0, 0, 0); 
  DELAY_100; /* Red */
}

/**
 * init_gpio_pins: initialize GPIO pins
 * args: void
 * return: void
 */
void init_gpio_pins() {
  #ifdef WIFIPLATE_TACT_PIN
  for(int i=0; i<NUM_RELAYS; i++)
  {
    pinMode(pushbutton[i], INPUT_PULLUP);
  }
  #endif
  #ifdef WIFIPLATE_TOUCH_PIN
  for(int i=0; i<NUM_RELAYS; i++)
  {
    pinMode(pushbutton[i], INPUT);
  }
  #endif
  pinMode(Red, OUTPUT);
  pinMode(Green, OUTPUT);
  pinMode(Blue, OUTPUT);
  pinMode(R1, OUTPUT);
  pinMode(R2, OUTPUT);
  pinMode(R3, OUTPUT);
  pinMode(JSON_INTERRUPT, OUTPUT);
  pinMode(HARD_RESET_BUTTON, INPUT_PULLUP);

  #ifdef WIFIMINI_AC_SWITCH
  for(int i=0; i <= NUM_RELAYS; i++) {
    pinMode(input_switch[i], INPUT_PULLDOWN);
  }
  #endif

  #ifdef WIFISTRIP_PINS
  pinMode(USB, OUTPUT);
  pinMode(OLED_RESET, INPUT);
  pinMode(NIGHT_LAMP, OUTPUT);
  #endif

  #if defined (WIFIMINI_PINS) || defined (WIFIPLATE_PINS)
  pinMode(R4, OUTPUT);
  #endif

  #ifdef WIFIMINI_8_PINS
  pinMode(R4, OUTPUT);
  pinMode(R5, OUTPUT);
  pinMode(R6, OUTPUT);
  pinMode(R7, OUTPUT);
  pinMode(R8, OUTPUT);
  #endif

  #ifdef WIFIPLATE_PINS
  pinMode(R4, OUTPUT);
  pinMode(R5, OUTPUT);
  pinMode(R6, OUTPUT);
  pinMode(R7, OUTPUT);
  pinMode(R8, OUTPUT);
  #endif
  digitalWrite(JSON_INTERRUPT, HIGH);
}

/**
 * args: void
 * returns:
 *  !0 for error
 *  0 for success
 */
int init_hardware() {
  // Initialize GPIO Pins
  /* ToDo :- fiexed error handling for oled and pins*/
  init_gpio_pins();

  // Oled Initialization
  // Not checked for error as global variable would
  // set against this.
  #ifdef WIFISTRIP
    oled_init();
  #endif
  int ret = nv_mount();
  if (ret != SUCCESS) {
    PRINTR("NV NOT MOUNT");
  }
  return ret;
}

/**
 * reset_and_toggle_relays - using single switch for clear nv and restart esp again and operating relays maually
 * args: void
 * return: void
 * to-do: need to decide on which core reset_nv has to run beacuse
 *    it might be possibilities of error like - ap_mode running on core_1 and interrupt
 *    running on core_0 then, due to delay in code possibilities of error will occur
 */
void reset_and_toggle_relays(void *pv) {
  PRINTS("reset_and_toggle_relays running on core ");
  PRINTR(xPortGetCoreID());
  int switch_count = 0;
  for(;;) {
    TIMERG0.wdt_wprotect = TIMG_WDT_WKEY_VALUE;
    TIMERG0.wdt_feed=1;
    TIMERG0.wdt_wprotect=0;
    int read_switch = digitalRead(HARD_RESET_BUTTON);
    if (read_switch == 0) {
      switch_count++;
      PRINTS("switch count = ");
      PRINTR(switch_count);
    }
    /* For toggle relays */
    if ((switch_count == 1) && (read_switch == 1)) {
    #ifdef WIFISTRIP
      for (int i = 1; i <= NUM_RELAYS; i++) {
        relay[i].state = 1;
        toggle_relay(i); // ALL onn
        switch_count = 2;
      }
      if ((WiFi.status() == WL_CONNECTED)) {
        /* Checking Wifi Status */
        String data = check_per_int(false, periodic_cmd);
        publish_on_periodic(data);
        DELAY_100;
      }
      //apply delay for avoiding reading
      DELAY_100;
    } else if (((switch_count == 3) || (switch_count == 4)) && (read_switch == 1)) {
      switch_count = 0;
      for (int i = 1; i <= NUM_RELAYS; i++) {
        relay[i].state = 0; //AL off
        toggle_relay(i);
      }
      if ((WiFi.status() == WL_CONNECTED)) { 
        /* Checking Wifi Status */
        String data = check_per_int(false, periodic_cmd);
        publish_on_periodic(data);
        DELAY_100;
      }
      //apply delay for avoiding reading
      DELAY_100;
      #endif
    } else if ((switch_count >= 3) && (read_switch == 1)) {
      switch_count = 0;      
    } else if ((switch_count >= 10) && (read_switch == 0)) {   /* For Reset NV */
      DELAY_1000;
      switch_count = 0;
      show_notification(please_wait, 7);
      if (WiFi.status() == WL_CONNECTED) {
        String delete_info = delete_response(device_delete);
        publish_on_delete(delete_info);
        PRINTR(delete_info);
      }
      DELAY_100;
      clear_nv();
      ESP.restart();
    }
    DELAY_100;
  }
}

/**
 * hard_switch - Using AC switch we can on and off relay and send relays data to cloud and from long press reset the device
 * args: void
 * return: void
 * to-do: need to decide on which core reset_nv has to run beacuse
 *    it might be possibilities of error like - ap_mode running on core_1 and interrupt
 *    running on core_0 then, due to delay in code possibilities of error will occur
 */
int last_button_state[NUM_RELAYS];
bool manually_on = false;
void hard_switch(void *pvParameters) {
  #ifdef WIFIMINI_AC_SWITCH
  for(;;)  {
    TIMERG0.wdt_wprotect = TIMG_WDT_WKEY_VALUE;
    TIMERG0.wdt_feed=1;
    TIMERG0.wdt_wprotect=0;

    for(int i = 1; i <= NUM_RELAYS; i++) {
      int button_state = digitalRead(input_switch[i-1]);
      if (last_button_state[i] != button_state) {
        if (button_state == HIGH) {
          relay[i].state = 1;
          PRINTR("toggle relay on");
          delay(100);
          toggle_relay(i);
          if (WiFi.status() == WL_CONNECTED) {
            /* Checking Wifi Status */
            periodic_response_send(false, true);
            DELAY_100;
          }
          manually_on = true;
        }
        if ((button_state == LOW) && (manually_on)) {
          relay[i].state = 0;
          PRINTR("toggle relay off");
          delay(100);
          toggle_relay(i);
          if (WiFi.status() == WL_CONNECTED) {
            /* Checking Wifi Status */
            periodic_response_send(false, true);
            DELAY_100;
          }
          manually_on = false;
        }
      }
      last_button_state[i] = button_state;
    } 
  }
  DELAY_100;
  #endif
}

/**
 * tac_switch - this task is for wifiplate using on off relays from a single button
 * args: void
 * return: void
 * to-do: need to decide on which core reset_nv has to run beacuse
 *    it might be possibilities of error like - ap_mode running on core_1 and interrupt
 *    running on core_0 then, due to delay in code possibilities of error will occur
 */
int counter = 0;
void tac_switch(void *pvParameters) {
  for(;;)  {
    TIMERG0.wdt_wprotect = TIMG_WDT_WKEY_VALUE;
    TIMERG0.wdt_feed=1;
    TIMERG0.wdt_wprotect=0;
    #ifdef WIFIPLATE
    for(int i=1; i<=NUM_RELAYS; i++) {
      int value = digitalRead(pushbutton[i-1]);
      int a = 0;
      if(value == LOW && a == 0) {
        counter++;
        a = 1;
      }
      if (counter == 15) {
        PRINTR(counter);
        counter = 0;
        if (relay[i].state == relay_onn) {
          relay[i].state = 0; // write state of relay in structure
          DELAY_100;
          toggle_relay(i); //toggle relay low
          DELAY_100;
          if ((WiFi.status() == WL_CONNECTED)) {
            /* Checking Wifi Status */
            String data = relays_response(true, periodic_cmd, false);
            publish_on_periodic(data);
            PRINTR("data low");
            PRINTR(data);
            DELAY_100;
          }
        } else if(relay[i].state == relay_off) {
          relay[i].state = 1;// write state of relay in structure
          DELAY_100;
          toggle_relay(i); //toggle relay HIGH
          DELAY_100;
          if ((WiFi.status() == WL_CONNECTED)) {
            /* Checking Wifi Status */
            String data = relays_response(true, periodic_cmd, false);
            publish_on_periodic(data);
            PRINTR(data);
            DELAY_100;
          }
        }
      }
    }
    #endif
  }
}

/**
 * cal_current - Using ACS712 we are calculating current and multiplied by 230 than get wattage.
 * args: void
 * returns: current and wattage
 */
void cal_current(void *pv) {
  PRINTS("Calculate Current ");
  for(;;) {
    TIMERG0.wdt_wprotect = TIMG_WDT_WKEY_VALUE;
    TIMERG0.wdt_feed=1;
    TIMERG0.wdt_wprotect=0;
    double Irms;
    #ifdef POWER_MEASUREMENT
    for (int i =0; i <= 50; i++) {
      Irms = emon1.calcIrms(1480);  // Calculate Irms onlyy
      if(Irms>= 0.08 && Irms <= 0.18) {
        Irms = 0;
      }
      wattage = (230 * Irms);
    }
    PRINTR("IRMS");
    PRINTR(Irms);
    avg_wattage = (wattage + avg_wattage)/2;
    dtostrf(avg_wattage,5,2,x);
    PRINTR("avg_wattage");
    PRINTR(avg_wattage);
    DELAY_60000;
  #endif
  }
}

/**
 * touch_switch - this task is for wifiplate using on off relays from a touch button
 * args: void
 * return: void
 */
int last_touch_state[NUM_RELAYS];
bool touch_on = false;
void touch_switch(void *pvParameters) {
  #ifdef WIFIPLATE_TOUCH_PIN
  for(;;)  {
    TIMERG0.wdt_wprotect = TIMG_WDT_WKEY_VALUE;
    TIMERG0.wdt_feed=1;
    TIMERG0.wdt_wprotect=0;

    for(int i = 1; i <= NUM_RELAYS; i++) {
      int touch_state = digitalRead(pushbutton[i-1]);
      delay(50);
      if (last_touch_state[i] != touch_state) {
        if (touch_state == HIGH) {
          DELAY_100;
          relay[i].state = 1;
          PRINTR("toggle relay on");
          toggle_relay(i);
          if (WiFi.status() == WL_CONNECTED) {
            /* Checking Wifi Status */
            periodic_response_send(false,true);
            DELAY_100;
          }
          touch_on = true;
        }
        if ((touch_state == LOW) && (touch_on)) {
          DELAY_100;
          relay[i].state = 0;
          PRINTR("toggle relay off");
          toggle_relay(i);
          if (WiFi.status() == WL_CONNECTED) {
            /* Checking Wifi Status */
            periodic_response_send(false,true);
            DELAY_100;
          }
          touch_on = false;
        }
      }
      last_touch_state[i] = touch_state;
    } 
  }
  DELAY_100;
  #endif
}