/******************************************************************************
 * Copyright 2020 IndiaSells
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *****************************************************************************/

#ifndef iotmqtt_h
#define iotmqtt_h

#include <Arduino.h>
#include "CloudCore.h"
#include <Client.h>
#include <MQTTClient.h>
#include "jwt.h"


class iotdevice {
 private:
  const char *project_id;
  const char *location;
  const char *registry_id;
  const char *device_id;
  NN_DIGIT priv_key[9];
  String jwt;
  int jwt_exp_secs;
  unsigned long exp_millis = 0;

 public:
  iotdevice();
  iotdevice(const char *project_id, const char *location,const char *registry_id, const char *device_id,const char *private_key);
  iotdevice &setProjectId(const char *project_id);
  iotdevice &setLocation(const char *location);
  iotdevice &setRegistryId(const char *registry_id);
  iotdevice &setDeviceId(const char *device_id);
  iotdevice &setPrivateKey(const char *private_key);
  void setJwtExpSecs(int exp_in_secs);
  int getJwtExpSecs();
  unsigned long getExpMillis();
  String createJWT(long long int time, int jwt_in_time);
  String getJWT();
  /* MQTT methods */
  String getClientId();
  String getCommandsTopic();
  String getConfigTopic();
  String getDeviceId();
  String getEventsTopic();
  //String getTelemetryTopic();
  String getStateTopic();
  //String getvc_configTopic();
};

class iotmqtt{
  private:
    int __backoff__ = 1000; // current backoff, milliseconds
    //static const int __factor__ = 2.5f;
    //static const int __minbackoff__ = 1000; // minimum backoff, ms
    //static const int __max_backoff__ = 60000; // maximum backoff, ms
    //static const int __jitter__ = 500; // max random jitter, ms
    boolean logConnect = true;
    boolean useLts = false;
    MQTTClient *mqttClient;
    Client *netClient;
    iotdevice *device;

  public:
    iotmqtt();
    iotmqtt(MQTTClient *mqttClient, Client *netClient, iotdevice *device);
    boolean loop();
    void mqttConnect(bool skip = false);
    void startMQTT();
    bool publishTelemetry(String data);
    bool publishState(const String &data);
    bool publishonsubtopic(String subtopic, String data);
    //bool publish_vc_config(const String &data);
    //int logConfiguration(bool showJWT);
    bool logError();
    bool logReturnCode();
    bool ret_error();
    void onConnect();
    void setLogConnect(boolean enabled);
    void setUseLts(boolean enabled);

};
#endif // iotmqtth